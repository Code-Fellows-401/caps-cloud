'use strict';

const AWS = require('aws-sdk');

AWS.config.update({ region: 'us-west-2' }); // Put your region here

const sns = new AWS.SNS();

const topic = 'arn:aws:sns:us-west-2:443681309443:pickup.fifo';

const payload = {
	message: 'testing',
	topic: topic,
};

sns
	.publish(payload)
	.promise()
	.then((metaData) => {
		console.log(metaData);
	})
	.catch((e) => {
		console.log(e);
	});
